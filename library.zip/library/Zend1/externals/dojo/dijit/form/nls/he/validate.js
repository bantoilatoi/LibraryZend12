({
	invalidMessage: "הערך שצוין אינו חוקי.",
	missingMessage: "זהו ערך דרוש.",
	rangeMessage: "הערך מחוץ לטווח."
})
