({
		previousMessage: "Eerdere opties",
		nextMessage: "Meer opties"
})
