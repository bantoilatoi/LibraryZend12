({
	buttonOk: "Tamam",
	buttonCancel: "İptal",
	buttonSave: "Kaydet",
	itemClose: "Kapat"
})
